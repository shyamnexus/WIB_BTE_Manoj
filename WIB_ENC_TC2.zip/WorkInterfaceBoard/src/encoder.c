#include "encoder.h"
#include "asf.h"
#include "FreeRTOS.h"
#include "task.h"
#include "can_app.h"

// Global encoder data structures
static encoder_data_t encoder1_data = {0};
static encoder_data_t encoder2_data = {0};

// CAN message IDs for encoder data
#define CAN_ID_ENCODER1_DIR_VEL    0x130u  // Encoder 1 direction and velocity
#define CAN_ID_ENCODER2_DIR_VEL    0x131u  // Encoder 2 direction and velocity

#ifndef TickType_t
typedef portTickType TickType_t; // Backward-compatible alias if TickType_t isn't defined
#endif
#ifndef pdMS_TO_TICKS
#define pdMS_TO_TICKS(ms) ((TickType_t)((ms) / portTICK_PERIOD_MS)) // Convert milliseconds to OS ticks
#endif

#ifndef portTICK_PERIOD_MS
#define portTICK_PERIOD_MS portTICK_RATE_MS // Legacy macro mapping
#endif

bool encoder_init(void)
{
    // Initialize encoder data structures
    encoder1_data.position = 0;
    encoder1_data.velocity = 0;
    encoder1_data.smoothed_velocity = 0;
    encoder1_data.direction = 0;
    encoder1_data.last_position = 0;
    encoder1_data.last_update_time = 0;
    encoder1_data.last_direction_change = 0;
    encoder1_data.pulse_count = 0;
    encoder1_data.velocity_window_start = 0;
    encoder1_data.tc_channel = TC_QUADRATURE_CHANNEL_ENC1;
    
    encoder2_data.position = 0;
    encoder2_data.velocity = 0;
    encoder2_data.smoothed_velocity = 0;
    encoder2_data.direction = 0;
    encoder2_data.last_position = 0;
    encoder2_data.last_update_time = 0;
    encoder2_data.last_direction_change = 0;
    encoder2_data.pulse_count = 0;
    encoder2_data.velocity_window_start = 0;
    encoder2_data.tc_channel = TC_QUADRATURE_CHANNEL_ENC2;
    
    // Initialize TC quadrature decoder
    if (!encoder_tc_init()) {
        return false;
    }
    
    // Enable PIO clocks for enable pins
    pmc_enable_periph_clk(ID_PIOD);
    
    // Configure enable pins as outputs and set them high (enable encoders)
    pio_configure(PIOD, PIO_OUTPUT_0, ENC1_ENABLE_PIN, PIO_DEFAULT);
    pio_clear(PIOD, ENC1_ENABLE_PIN);  // Enable encoder 1
    
    if (ENCODER2_AVAILABLE) {
        pio_configure(PIOD, PIO_OUTPUT_0, ENC2_ENABLE_PIN, PIO_DEFAULT);
        pio_clear(PIOD, ENC2_ENABLE_PIN);  // Enable encoder 2
    }
    
    return true;
}

bool encoder_tc_init(void)
{
    // Enable TC0 peripheral clock
    pmc_enable_periph_clk(ID_TC0);
    
    // Initialize TC0 channel 0 for ENC1
    if (!encoder_tc_channel_init(TC_QUADRATURE_CHANNEL_ENC1)) {
        return false;
    }
    
    // Initialize TC0 channel 1 for ENC2 if available
    if (ENCODER2_AVAILABLE) {
        if (!encoder_tc_channel_init(TC_QUADRATURE_CHANNEL_ENC2)) {
            return false;
        }
    }
    
    return true;
}

bool encoder_tc_channel_init(uint32_t channel)
{
    // Configure PIO for TC TIOA and TIOB pins
    if (channel == TC_QUADRATURE_CHANNEL_ENC1) {
        // Configure PA5 as TIOA0 and PA1 as TIOB0
        pio_configure(PIOA, PIO_PERIPH_A, PIO_PA5, PIO_DEFAULT);  // TIOA0
        pio_configure(PIOA, PIO_PERIPH_A, PIO_PA1, PIO_DEFAULT);  // TIOB0
    } else if (channel == TC_QUADRATURE_CHANNEL_ENC2) {
        // Configure PA15 as TIOA1 and PA16 as TIOB1
        pio_configure(PIOA, PIO_PERIPH_A, PIO_PA15, PIO_DEFAULT); // TIOA1
        pio_configure(PIOA, PIO_PERIPH_A, PIO_PA16, PIO_DEFAULT); // TIOB1
    } else {
        return false;
    }
    
    // Configure TC for quadrature decoder mode
    // Set up Block Mode Register for quadrature decoding
    TC0->TC_BMR = TC_BMR_QDEN |                    // Enable quadrature decoder
                  TC_BMR_POSEN |                   // Enable position counting
                  TC_BMR_SPEEDEN |                 // Enable speed counting
                  TC_BMR_FILTER |                  // Enable glitch filter
                  TC_BMR_MAXFILT(TC_QUADRATURE_FILTER); // Set filter value
    
    // Configure channel mode register for quadrature decoder
    // Clock selection: XC0 for channel 0, XC1 for channel 1
    uint32_t clock_sel = (channel == 0) ? TC_CMR_TCCLKS_XC0 : TC_CMR_TCCLKS_XC1;
    TC0->TC_CHANNEL[channel].TC_CMR = clock_sel;
    
    // Enable the channel
    TC0->TC_CHANNEL[channel].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;
    
    return true;
}

uint32_t encoder_tc_get_position(uint32_t channel)
{
    if (channel >= 3) return 0; // Invalid channel
    
    // Read the current counter value
    return TC0->TC_CHANNEL[channel].TC_CV;
}

void encoder_tc_reset_position(uint32_t channel)
{
    if (channel >= 3) return; // Invalid channel
    
    // Reset the counter by disabling and re-enabling
    TC0->TC_CHANNEL[channel].TC_CCR = TC_CCR_CLKDIS;
    TC0->TC_CHANNEL[channel].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;
}

uint8_t encoder_tc_get_direction(uint32_t channel)
{
    if (channel >= 3) return 0; // Invalid channel
    
    // Read direction from QDEC status register
    uint32_t qisr = TC0->TC_QISR;
    
    // Check if direction change interrupt is pending
    if (qisr & TC_QISR_DIRCHG) {
        // Read direction bit
        return (qisr & TC_QISR_DIR) ? 2 : 1; // 1=forward, 2=reverse
    }
    
    return 0; // No direction change or stopped
}

void encoder_poll(encoder_data_t* enc_data)
{
    // Skip polling if this is encoder2 and it's not available
    if (enc_data == &encoder2_data && !ENCODER2_AVAILABLE) {
        return;
    }
    
    // Get current time (using FreeRTOS tick count)
    uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    // Read current position from TC counter
    uint32_t current_position = encoder_tc_get_position(enc_data->tc_channel);
    
    // Check for position change
    if (current_position != enc_data->last_position) {
        // Calculate direction based on position change
        uint8_t new_direction = 0;
        if (current_position > enc_data->last_position) {
            new_direction = 1; // Forward
        } else if (current_position < enc_data->last_position) {
            new_direction = 2; // Reverse
        }
        
        // Update position
        enc_data->position = current_position;
        
        // Update direction only if change is allowed (debouncing)
        if (is_direction_change_allowed(enc_data, current_time, new_direction)) {
            enc_data->direction = new_direction;
            enc_data->last_direction_change = current_time;
        }
        
        // Calculate pulse count for velocity calculation
        uint32_t position_delta = (current_position > enc_data->last_position) ? 
                                 (current_position - enc_data->last_position) : 
                                 (enc_data->last_position - current_position);
        enc_data->pulse_count += position_delta;
        
        enc_data->last_position = current_position;
        enc_data->last_update_time = current_time;
    } else {
        // No position change - check if we should reset direction to stopped
        if (current_time - enc_data->last_update_time > 50) { // 50ms timeout
            enc_data->direction = 0; // Stopped
        }
    }
    
    // Calculate velocity periodically
    if (current_time - enc_data->velocity_window_start >= VELOCITY_CALC_WINDOW_MS) {
        enc_data->velocity = calculate_velocity(enc_data, current_time);
        apply_velocity_smoothing(enc_data);
        enc_data->velocity_window_start = current_time;
        enc_data->pulse_count = 0;
    }
}

int32_t calculate_velocity(encoder_data_t* enc_data, uint32_t current_time)
{
    if (enc_data->velocity_window_start == 0) {
        enc_data->velocity_window_start = current_time;
        return 0;
    }
    
    uint32_t time_diff = current_time - enc_data->velocity_window_start;
    if (time_diff == 0) return 0;
    
    // Calculate velocity in pulses per second
    int32_t velocity = (enc_data->pulse_count * 1000) / time_diff;
    
    // Apply direction sign
    if (enc_data->direction == 2) { // Reverse
        velocity = -velocity;
    }
    
    return velocity;
}

void apply_velocity_smoothing(encoder_data_t* enc_data)
{
    // Apply exponential smoothing to reduce jerky velocity changes
    float smoothing_factor = VELOCITY_SMOOTHING_FACTOR;
    enc_data->smoothed_velocity = (int32_t)(smoothing_factor * enc_data->smoothed_velocity + 
                                           (1.0f - smoothing_factor) * enc_data->velocity);
}

bool is_direction_change_allowed(encoder_data_t* enc_data, uint32_t current_time, uint8_t new_direction)
{
    // Don't allow direction changes if we're already in that direction
    if (enc_data->direction == new_direction) {
        return false;
    }
    
    // Don't allow direction changes too frequently (debouncing)
    if (current_time - enc_data->last_direction_change < DIRECTION_DEBOUNCE_MS) {
        return false;
    }
    
    // Only allow direction change if we have some velocity (not just noise)
    if (abs(enc_data->velocity) < 2) { // Minimum velocity threshold
        return false;
    }
    
    return true;
}

void encoder_task(void *arg)
{
    (void)arg; // Unused parameter
    
    // Initialize encoders with TC quadrature decoder approach
    if (!encoder_init()) {
        // Encoder initialization failed
        while(1) {
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
    
    // Wait a bit for encoders to stabilize
    vTaskDelay(pdMS_TO_TICKS(100));
    
    uint32_t last_enc1_position = 0;
    uint32_t last_enc2_position = 0;
    uint32_t last_transmission_time = 0;
    
    for (;;) {
        uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
        
        // Poll both encoders
        encoder_poll(&encoder1_data);
        if (ENCODER2_AVAILABLE) {
            encoder_poll(&encoder2_data);
        }
        
        // Send encoder data over CAN periodically
        if (current_time - last_transmission_time >= ENCODER_POLLING_RATE_MS) {
            // Prepare CAN message for encoder 1
            uint8_t enc1_data[8];
            
            // Pack position (4 bytes)
            enc1_data[0] = (uint8_t)(encoder1_data.position & 0xFF);
            enc1_data[1] = (uint8_t)((encoder1_data.position >> 8) & 0xFF);
            enc1_data[2] = (uint8_t)((encoder1_data.position >> 16) & 0xFF);
            enc1_data[3] = (uint8_t)((encoder1_data.position >> 24) & 0xFF);
            
            // Pack velocity (4 bytes)
            enc1_data[4] = (uint8_t)(encoder1_data.velocity & 0xFF);
            enc1_data[5] = (uint8_t)((encoder1_data.velocity >> 8) & 0xFF);
            enc1_data[6] = (uint8_t)((encoder1_data.velocity >> 16) & 0xFF);
            enc1_data[7] = (uint8_t)((encoder1_data.velocity >> 24) & 0xFF);
            
            can_app_tx(CAN_ID_ENCODER1_DIR_VEL, enc1_data, 8);
            
            // Send encoder 2 data if available
            if (ENCODER2_AVAILABLE) {
                uint8_t enc2_data[8];
                
                // Pack position (4 bytes)
                enc2_data[0] = (uint8_t)(encoder2_data.position & 0xFF);
                enc2_data[1] = (uint8_t)((encoder2_data.position >> 8) & 0xFF);
                enc2_data[2] = (uint8_t)((encoder2_data.position >> 16) & 0xFF);
                enc2_data[3] = (uint8_t)((encoder2_data.position >> 24) & 0xFF);
                
                // Pack velocity (4 bytes)
                enc2_data[4] = (uint8_t)(encoder2_data.velocity & 0xFF);
                enc2_data[5] = (uint8_t)((encoder2_data.velocity >> 8) & 0xFF);
                enc2_data[6] = (uint8_t)((encoder2_data.velocity >> 16) & 0xFF);
                enc2_data[7] = (uint8_t)((encoder2_data.velocity >> 24) & 0xFF);
                
                can_app_tx(CAN_ID_ENCODER2_DIR_VEL, enc2_data, 8);
            }
            
            last_transmission_time = current_time;
        }
        
        // Wait for next transmission cycle
        vTaskDelay(pdMS_TO_TICKS(ENCODER_POLLING_RATE_MS));
    }
}